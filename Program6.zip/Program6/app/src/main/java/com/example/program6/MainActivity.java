package com.example.program6;

import static android.app.ProgressDialog.show;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    Button b;

    EditText txtnum,txtmsg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        b=findViewById(R.id.button);
        txtnum=findViewById(R.id.editTextNumber);
        txtmsg=findViewById(R.id.editTextTextMultiLine);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    SmsManager smgr=SmsManager.getDefault();
                    smgr.sendTextMessage(txtnum.getText().toString(),null,txtmsg.getText().toString(),null,null);

                    Toast.makeText(MainActivity.this,"SMS Sent Successfully", Toast.LENGTH_SHORT).show();
                }

                catch(Exception e){
                    Toast.makeText(MainActivity.this,"Please try again", Toast.LENGTH_SHORT).show();

                }
            }
        });




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
package com.example.program5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button l_btn,c_btn;
    EditText u_txt,p_txt;
    DbHandler db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        l_btn = findViewById(R.id.button);
        c_btn = findViewById(R.id.button2);
        u_txt = findViewById(R.id.editTextText);
        p_txt = findViewById(R.id.editTextTextPassword);

        l_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = u_txt.getText().toString();
                String password = p_txt.getText().toString();
                int id = checkUser(new User(name, password));
                if (id == -1) {
                    Toast.makeText(MainActivity.this, "User does not Exist", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Username " + name + " Exist", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, secondactivity.class);
                    startActivity(intent);
                }
            }

        });

        c_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u_txt.setText("");
                p_txt.setText("");
            }
        });



        db = new DbHandler(MainActivity.this);
        db.addUser(new User("Prajwal", "1234"));
        db.addUser(new User("Bhargav", "4567"));
        db.addUser(new User("ujwal", "7890"));
    }

        public int checkUser(User user)
        {
            return db.checkUser(user);
        }

}